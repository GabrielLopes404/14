import type { Express } from "express";
import { createServer, type Server } from "http";
import session from "express-session";
import { type User } from "@shared/schema";

import authRoutes from "./routes/auth.routes";
import contasRoutes from "./routes/contas.routes";
import faturasRoutes from "./routes/faturas.routes";
import contatosRoutes from "./routes/contatos.routes";
import fluxoCaixaRoutes from "./routes/fluxo-caixa.routes";
import conciliacoesRoutes from "./routes/conciliacoes.routes";
import dashboardRoutes from "./routes/dashboard.routes";
import adminRoutes from "./routes/admin.routes";

declare module 'express-session' {
  interface SessionData {
    userId: string;
  }
}

declare global {
  namespace Express {
    interface Request {
      user?: User;
    }
  }
}

export async function registerRoutes(app: Express): Promise<Server> {
  const sessionSecret = process.env.SESSION_SECRET || "af5k6+NUmx10I3hl/BIECh6UQb2khM/2HaCs2+iXkBs=";
  
  app.use(session({
    secret: sessionSecret,
    resave: false,
    saveUninitialized: false,
    cookie: {
      secure: false,
      httpOnly: true,
      maxAge: 1000 * 60 * 60 * 24 * 7,
    }
  }));

  app.use("/api/auth", authRoutes);
  app.use("/api/contas", contasRoutes);
  app.use("/api/faturas", faturasRoutes);
  app.use("/api/contatos", contatosRoutes);
  app.use("/api/fluxo-caixa", fluxoCaixaRoutes);
  app.use("/api/conciliacoes", conciliacoesRoutes);
  app.use("/api/dashboard", dashboardRoutes);
  app.use("/api/admin", adminRoutes);

  const httpServer = createServer(app);
  return httpServer;
}
