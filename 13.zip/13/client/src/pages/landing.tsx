import { useState, useEffect } from "react";
import { motion, useScroll, useTransform } from "framer-motion";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { 
  ArrowRight, 
  CheckCircle2, 
  TrendingUp, 
  DollarSign, 
  Shield, 
  Zap,
  Users,
  BarChart3,
  Star,
  Sparkles,
  Target,
  Clock,
  LineChart,
  PieChart,
  Wallet,
  CreditCard,
  FileText,
  Calculator,
  Building2,
  Phone,
  Mail,
  MapPin,
  ChevronDown,
  Heart,
  Receipt,
  Lock,
  Headphones,
  Award,
  Rocket,
  TrendingDown,
  Activity
} from "lucide-react";
import { Link } from "wouter";
import {
  Accordion,
  AccordionContent,
  AccordionItem,
  AccordionTrigger,
} from "@/components/ui/accordion";

const fadeInUp = {
  initial: { opacity: 0, y: 60 },
  animate: { opacity: 1, y: 0 },
  transition: { duration: 0.6 }
};

const stagger = {
  animate: {
    transition: {
      staggerChildren: 0.1
    }
  }
};

const features = [
  {
    icon: Zap,
    title: "Baixo custo",
    description: "Preço super justo que cabe no seu bolso",
    gradient: "from-violet-500 to-purple-500"
  },
  {
    icon: Heart,
    title: "Fácil de usar",
    description: "Super intuitivo! Descomplicado e do nosso jeito",
    gradient: "from-pink-500 to-rose-500"
  },
  {
    icon: Sparkles,
    title: "Simples e completo",
    description: "Tudo o que você precisa para uma boa gestão financeira",
    gradient: "from-blue-500 to-cyan-500"
  },
  {
    icon: TrendingUp,
    title: "Evolua a cada dia",
    description: "Equipe dedicada no desenvolvimento de melhorias",
    gradient: "from-indigo-500 to-purple-500"
  },
];

const mainFeatures = [
  {
    icon: Receipt,
    title: "Contas a Pagar e Receber",
    description: "Com o recurso de 'Lançamentos Recorrentes' você lança uma única vez todas as suas despesas e recebimentos. Mais praticidade no seu dia a dia!",
    color: "text-blue-600",
    gradient: "from-blue-500 to-cyan-500"
  },
  {
    icon: LineChart,
    title: "Fluxo de Caixa",
    description: "O Fluxo de Caixa é a espinha dorsal de qualquer negócio bem-sucedido. Com o nosso sistema, você terá uma visão clara de como o dinheiro está fluindo na sua empresa.",
    color: "text-violet-600",
    gradient: "from-violet-500 to-purple-500"
  },
  {
    icon: CreditCard,
    title: "Pagamentos Pendentes",
    description: "Todas as contas pendentes em um único lugar. Controle total sobre o que precisa ser pago e recebido.",
    color: "text-purple-600",
    gradient: "from-purple-500 to-pink-500"
  },
  {
    icon: Lock,
    title: "Gestão e Permissões de Acessos",
    description: "Tenha controle total sobre as informações financeiras dentro da sua empresa. Os administradores podem definir as ações que os demais usuários podem realizar no sistema.",
    color: "text-indigo-600",
    gradient: "from-indigo-500 to-blue-500"
  },
  {
    icon: Building2,
    title: "Gestão de Contas Bancárias",
    description: "Monitore seus saldos bancários atuais dos registros das transações financeiras e conciliação bancária. Gerencie suas contas de investimentos, cartões pré-pago e a caixa.",
    color: "text-blue-600",
    gradient: "from-blue-500 to-indigo-500"
  },
  {
    icon: FileText,
    title: "Gestão de Faturas",
    description: "Crie e envie faturas profissionais para seus clientes. Acompanhe pagamentos e mantenha seu fluxo de caixa organizado.",
    color: "text-purple-600",
    gradient: "from-purple-500 to-violet-500"
  }
];

const stats = [
  { value: "+3.610", label: "Empresas cadastradas", icon: Building2, gradient: "from-violet-500 to-purple-500" },
  { value: "+3.610", label: "Usuários cadastrados", icon: Users, gradient: "from-blue-500 to-cyan-500" },
  { value: "+3.610", label: "Contas criadas", icon: Wallet, gradient: "from-pink-500 to-rose-500" },
  { value: "+36.100", label: "Transações realizadas", icon: TrendingUp, gradient: "from-indigo-500 to-purple-500" },
];

const testimonials = [
  {
    name: "Eduardo Henrique",
    role: "CEO da TechFlow",
    company: "Empresa de tecnologia e desenvolvimento",
    content: "O Lucrei transformou completamente a gestão financeira das minhas empresas. Agora tenho total controle e transparência sobre todas as operações.",
    avatar: "EH",
    rating: 5,
    gradient: "from-violet-500 to-purple-500"
  },
  {
    name: "Denys Lucio",
    role: "MEI Autônomo",
    company: "Consultor Financeiro",
    content: "Desde que comecei a usar a plataforma, minha vida financeira ficou muito mais organizada. É simples, rápido e eficiente!",
    avatar: "DL",
    rating: 5,
    gradient: "from-blue-500 to-cyan-500"
  },
  {
    name: "Bruna Soledo Alves",
    role: "Gestora e Arquiteta",
    company: "BS Arquitetura",
    content: "Uso Lucrei há 28 meses! Sistema bem organizado, rápido e completo. É o melhor que já encontrei no mercado para gestão financeira.",
    avatar: "BS",
    rating: 5,
    gradient: "from-pink-500 to-rose-500"
  }
];

const plans = [
  {
    name: "Mensal",
    price: "39",
    period: "/mês",
    description: "Ideal para começar",
    discount: null,
    features: [
      "Controle financeiro completo",
      "Gestão de contratos",
      "Até 3 usuários",
      "Acesso a API",
      "50 GB de armazenamento",
      "Suporte por email"
    ],
    gradient: "from-emerald-500 to-green-600",
    popular: false
  },
  {
    name: "Semestral",
    price: "209",
    period: "/semestre",
    description: "Mais economia",
    discount: "Economize 12%",
    features: [
      "Tudo do plano Mensal",
      "Até 5 usuários",
      "100 GB de armazenamento",
      "Suporte prioritário",
      "Relatórios avançados",
      "Integrações premium"
    ],
    gradient: "from-blue-500 to-indigo-600",
    popular: true
  },
  {
    name: "Anual",
    price: "399",
    period: "/ano",
    description: "Melhor custo-benefício",
    discount: "Economize 15%",
    features: [
      "Tudo do plano Semestral",
      "Usuários ilimitados",
      "200 GB de armazenamento",
      "Suporte 24/7",
      "Consultoria mensal",
      "White label"
    ],
    gradient: "from-pink-500 to-purple-600",
    popular: false
  }
];

const faqs = [
  {
    question: "O que é o Lucrei?",
    answer: "Lucrei é um sistema completo de gestão financeira voltado para MEI, micro e pequenas empresas. Com ele você gerencia suas receitas, despesas, fluxo de caixa e muito mais de forma simples e intuitiva."
  },
  {
    question: "É possível importar dados de outros sistemas?",
    answer: "Sim! Oferecemos integração via API e também importação de arquivos OFX para facilitar a migração dos seus dados de outros sistemas."
  },
  {
    question: "Preciso criar uma conta para usar o Lucrei?",
    answer: "Sim, mas é super rápido! Você pode começar com nosso teste gratuito de 7 dias sem precisar de cartão de crédito."
  },
  {
    question: "O sistema é seguro?",
    answer: "Absolutamente! Utilizamos criptografia de ponta a ponta, servidores seguros e fazemos backups diários dos seus dados. Sua segurança é nossa prioridade."
  },
  {
    question: "Posso usar em dispositivos móveis?",
    answer: "Sim! O Lucrei é totalmente responsivo e funciona perfeitamente em smartphones, tablets e computadores."
  },
  {
    question: "Como funciona o suporte?",
    answer: "Oferecemos suporte por email para todos os planos, suporte prioritário no plano semestral e suporte 24/7 no plano anual."
  }
];

export default function Landing() {
  const [isScrolled, setIsScrolled] = useState(false);
  const { scrollY } = useScroll();
  const headerBg = useTransform(scrollY, [0, 100], ["rgba(15, 23, 42, 0)", "rgba(15, 23, 42, 0.95)"]);

  useEffect(() => {
    const handleScroll = () => setIsScrolled(window.scrollY > 50);
    window.addEventListener("scroll", handleScroll);
    return () => window.removeEventListener("scroll", handleScroll);
  }, []);

  return (
    <div className="min-h-screen bg-gradient-to-b from-slate-950 via-slate-900 to-slate-950 text-white overflow-hidden">
      {/* Header/Navbar */}
      <motion.header
        className="fixed top-0 left-0 right-0 z-50 border-b border-white/5"
        style={{ backgroundColor: headerBg }}
      >
        <nav className="container mx-auto px-4 sm:px-6 lg:px-8 py-4">
          <div className="flex items-center justify-between">
            <Link href="/">
              <motion.div
                className="flex items-center gap-2 sm:gap-3 cursor-pointer"
                whileHover={{ scale: 1.05 }}
                whileTap={{ scale: 0.95 }}
              >
                <div className="p-2 sm:p-2.5 bg-gradient-to-br from-violet-500 to-purple-500 rounded-xl">
                  <Zap className="h-5 w-5 sm:h-6 sm:w-6 text-white" />
                </div>
                <span className="text-xl sm:text-2xl font-bold bg-gradient-to-r from-violet-400 via-purple-400 to-pink-400 bg-clip-text text-transparent">
                  Lucrei
                </span>
              </motion.div>
            </Link>

            <div className="hidden lg:flex items-center gap-8">
              <a href="#recursos" className="text-sm font-medium text-slate-300 hover:text-white transition-colors">Recursos</a>
              <a href="#quem-somos" className="text-sm font-medium text-slate-300 hover:text-white transition-colors">Para quem</a>
              <a href="#depoimentos" className="text-sm font-medium text-slate-300 hover:text-white transition-colors">Depoimentos</a>
              <a href="#precos" className="text-sm font-medium text-slate-300 hover:text-white transition-colors">Preços</a>
            </div>

            <div className="flex items-center gap-2 sm:gap-3">
              <Link href="/login">
                <Button variant="ghost" className="text-sm sm:text-base text-slate-300 hover:text-white hover:bg-white/5">
                  <Users className="h-4 w-4 mr-2" />
                  <span className="hidden sm:inline">Trabalhe Aqui?</span>
                  <span className="sm:hidden">Entrar</span>
                </Button>
              </Link>
              <Link href="/login">
                <Button className="text-sm sm:text-base bg-gradient-to-r from-violet-500 via-purple-500 to-pink-500 hover:from-violet-600 hover:via-purple-600 hover:to-pink-600 shadow-lg shadow-purple-500/30">
                  <Zap className="h-4 w-4 mr-2" />
                  <span className="hidden sm:inline">Entrar Agora</span>
                  <span className="sm:hidden">Entrar</span>
                </Button>
              </Link>
            </div>
          </div>
        </nav>
      </motion.header>

      {/* Hero Section */}
      <section className="relative pt-32 sm:pt-40 pb-20 sm:pb-32 overflow-hidden">
        {/* Animated Background */}
        <div className="absolute inset-0">
          <div className="absolute top-1/4 left-1/4 w-96 h-96 bg-violet-500/20 rounded-full blur-3xl animate-pulse" />
          <div className="absolute bottom-1/4 right-1/4 w-96 h-96 bg-purple-500/20 rounded-full blur-3xl animate-pulse" style={{ animationDelay: "1s" }} />
          <div className="absolute top-1/2 left-1/2 w-96 h-96 bg-pink-500/20 rounded-full blur-3xl animate-pulse" style={{ animationDelay: "2s" }} />
        </div>

        {/* Grid Pattern */}
        <div className="absolute inset-0 bg-[linear-gradient(to_right,#80808012_1px,transparent_1px),linear-gradient(to_bottom,#80808012_1px,transparent_1px)] bg-[size:24px_24px]" />

        <div className="container mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
          <div className="max-w-5xl mx-auto text-center">
            {/* Badge */}
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.5 }}
              className="inline-flex"
            >
              <Badge className="mb-6 sm:mb-8 px-4 sm:px-6 py-2 bg-gradient-to-r from-violet-500/20 to-purple-500/20 border-violet-500/30 text-violet-300 text-xs sm:text-sm">
                <Sparkles className="h-3 w-3 sm:h-4 sm:w-4 mr-2" />
                7 Dias Grátis - Sem Cartão de Crédito
              </Badge>
            </motion.div>

            {/* Main Heading */}
            <motion.h1
              {...fadeInUp}
              className="text-4xl sm:text-5xl md:text-6xl lg:text-7xl font-bold leading-tight mb-6 sm:mb-8"
            >
              Você no{" "}
              <span className="bg-gradient-to-r from-violet-400 via-purple-400 to-pink-400 bg-clip-text text-transparent">
                comando
              </span>
              {" "}das{" "}
              <span className="bg-gradient-to-r from-pink-400 via-purple-400 to-violet-400 bg-clip-text text-transparent">
                finanças
              </span>
            </motion.h1>

            <motion.p
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.2, duration: 0.5 }}
              className="text-base sm:text-lg md:text-xl text-slate-400 mb-10 sm:mb-12 max-w-3xl mx-auto px-4"
            >
              Tudo o que você precisa para gerenciar suas finanças com
              inteligência, simplicidade e total controle sobre o seu dinheiro.
            </motion.p>

            {/* CTA Buttons */}
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.4, duration: 0.5 }}
              className="flex flex-col sm:flex-row items-center justify-center gap-4 px-4"
            >
              <Link href="/login">
                <Button size="lg" className="w-full sm:w-auto text-base sm:text-lg px-6 sm:px-8 h-12 sm:h-14 bg-gradient-to-r from-violet-500 via-purple-500 to-pink-500 hover:from-violet-600 hover:via-purple-600 hover:to-pink-600 shadow-2xl shadow-purple-500/50 group">
                  <Rocket className="h-5 w-5 mr-2 group-hover:rotate-12 transition-transform" />
                  Começar Gratuitamente
                  <ArrowRight className="h-5 w-5 ml-2 group-hover:translate-x-1 transition-transform" />
                </Button>
              </Link>
              <Button size="lg" variant="outline" className="w-full sm:w-auto text-base sm:text-lg px-6 sm:px-8 h-12 sm:h-14 border-2 border-white/20 hover:bg-white/5 hover:border-white/30">
                <Activity className="h-5 w-5 mr-2" />
                Ver Demonstração
              </Button>
            </motion.div>

            {/* Trust Indicators */}
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              transition={{ delay: 0.6, duration: 0.5 }}
              className="mt-12 sm:mt-16 flex flex-wrap items-center justify-center gap-6 sm:gap-8 text-xs sm:text-sm text-slate-400"
            >
              <div className="flex items-center gap-2">
                <CheckCircle2 className="h-4 w-4 sm:h-5 sm:w-5 text-green-400" />
                <span>Sem Cartão de Crédito</span>
              </div>
              <div className="flex items-center gap-2">
                <Shield className="h-4 w-4 sm:h-5 sm:w-5 text-blue-400" />
                <span>100% Seguro</span>
              </div>
              <div className="flex items-center gap-2">
                <Clock className="h-4 w-4 sm:h-5 sm:w-5 text-violet-400" />
                <span>Suporte 24/7</span>
              </div>
            </motion.div>
          </div>
        </div>

        {/* Scroll Indicator */}
        <motion.div
          className="absolute bottom-8 left-1/2 -translate-x-1/2 hidden md:block"
          animate={{ y: [0, 10, 0] }}
          transition={{ duration: 2, repeat: Infinity }}
        >
          <ChevronDown className="h-8 w-8 text-slate-500" />
        </motion.div>
      </section>

      {/* Stats Section */}
      <section className="py-12 sm:py-20 relative">
        <div className="container mx-auto px-4 sm:px-6 lg:px-8">
          <motion.div
            variants={stagger}
            initial="initial"
            whileInView="animate"
            viewport={{ once: true }}
            className="grid grid-cols-2 lg:grid-cols-4 gap-4 sm:gap-8"
          >
            {stats.map((stat, index) => (
              <motion.div
                key={index}
                variants={fadeInUp}
                whileHover={{ scale: 1.05, y: -5 }}
              >
                <Card className="bg-slate-900/50 border-white/10 backdrop-blur-sm hover:border-white/20 transition-all">
                  <CardContent className="p-4 sm:p-6 text-center">
                    <div className={`inline-flex p-3 sm:p-4 rounded-xl bg-gradient-to-br ${stat.gradient} mb-3 sm:mb-4`}>
                      <stat.icon className="h-6 w-6 sm:h-8 sm:w-8 text-white" />
                    </div>
                    <div className="text-2xl sm:text-3xl font-bold bg-gradient-to-r from-white to-slate-300 bg-clip-text text-transparent mb-1 sm:mb-2">
                      {stat.value}
                    </div>
                    <div className="text-xs sm:text-sm text-slate-400">{stat.label}</div>
                  </CardContent>
                </Card>
              </motion.div>
            ))}
          </motion.div>
        </div>
      </section>

      {/* Features Section */}
      <section id="recursos" className="py-16 sm:py-24 relative">
        <div className="container mx-auto px-4 sm:px-6 lg:px-8">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.5 }}
            className="text-center mb-12 sm:mb-16"
          >
            <Badge className="mb-4 bg-violet-500/20 border-violet-500/30 text-violet-300">
              Recursos Poderosos
            </Badge>
            <h2 className="text-3xl sm:text-4xl md:text-5xl font-bold mb-4 sm:mb-6">
              Tudo que você precisa,{" "}
              <span className="bg-gradient-to-r from-violet-400 to-purple-400 bg-clip-text text-transparent">
                em um só lugar
              </span>
            </h2>
            <p className="text-base sm:text-lg md:text-xl text-slate-400 max-w-2xl mx-auto">
              Ferramentas profissionais para gestão financeira completa
            </p>
          </motion.div>

          <motion.div
            variants={stagger}
            initial="initial"
            whileInView="animate"
            viewport={{ once: true }}
            className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6 sm:gap-8"
          >
            {mainFeatures.map((feature, index) => (
              <motion.div key={index} variants={fadeInUp} whileHover={{ y: -8, scale: 1.02 }}>
                <Card className="h-full bg-slate-900/50 border-white/10 backdrop-blur-sm hover:border-white/20 transition-all group">
                  <CardContent className="p-6 sm:p-8">
                    <div className={`inline-flex p-3 sm:p-4 rounded-xl bg-gradient-to-br ${feature.gradient} mb-4 sm:mb-6 group-hover:scale-110 transition-transform`}>
                      <feature.icon className="h-6 w-6 sm:h-8 sm:w-8 text-white" />
                    </div>
                    <h3 className="text-lg sm:text-xl font-bold mb-2 sm:mb-3 text-white group-hover:text-violet-300 transition-colors">
                      {feature.title}
                    </h3>
                    <p className="text-sm sm:text-base text-slate-400 leading-relaxed">
                      {feature.description}
                    </p>
                  </CardContent>
                </Card>
              </motion.div>
            ))}
          </motion.div>
        </div>
      </section>

      {/* Why Choose Section */}
      <section id="quem-somos" className="py-16 sm:py-24 bg-gradient-to-b from-transparent via-slate-900/50 to-transparent">
        <div className="container mx-auto px-4 sm:px-6 lg:px-8">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            className="grid md:grid-cols-2 gap-8 sm:gap-12 items-center"
          >
            <div>
              <Badge className="mb-4 bg-pink-500/20 border-pink-500/30 text-pink-300">
                Por que escolher o Lucrei?
              </Badge>
              <h2 className="text-3xl sm:text-4xl md:text-5xl font-bold mb-4 sm:mb-6">
                Feito para{" "}
                <span className="bg-gradient-to-r from-pink-400 to-purple-400 bg-clip-text text-transparent">
                  simplificar
                </span>
                {" "}sua vida
              </h2>
              <p className="text-base sm:text-lg text-slate-400 mb-6 sm:mb-8">
                Desenvolvemos o Lucrei pensando em você: MEI, autônomo, micro e pequena empresa.
                Um sistema completo, profissional e fácil de usar.
              </p>

              <div className="space-y-4 sm:space-y-6">
                {features.map((feature, index) => (
                  <motion.div
                    key={index}
                    initial={{ opacity: 0, x: -20 }}
                    whileInView={{ opacity: 1, x: 0 }}
                    viewport={{ once: true }}
                    transition={{ delay: index * 0.1 }}
                    className="flex items-start gap-3 sm:gap-4"
                  >
                    <div className={`p-2 sm:p-3 rounded-lg bg-gradient-to-br ${feature.gradient} shrink-0`}>
                      <feature.icon className="h-5 w-5 sm:h-6 sm:w-6 text-white" />
                    </div>
                    <div>
                      <h4 className="text-base sm:text-lg font-bold mb-1 text-white">{feature.title}</h4>
                      <p className="text-sm sm:text-base text-slate-400">{feature.description}</p>
                    </div>
                  </motion.div>
                ))}
              </div>
            </div>

            <motion.div
              initial={{ opacity: 0, scale: 0.8 }}
              whileInView={{ opacity: 1, scale: 1 }}
              viewport={{ once: true }}
              className="relative"
            >
              <div className="relative aspect-square rounded-2xl overflow-hidden border-2 border-white/10 bg-gradient-to-br from-violet-500/20 to-purple-500/20 backdrop-blur-sm p-6 sm:p-8">
                <div className="absolute inset-0 bg-gradient-to-br from-violet-500/10 to-purple-500/10" />
                <div className="relative z-10 h-full flex flex-col justify-center items-center text-center">
                  <div className="p-4 sm:p-6 bg-gradient-to-br from-violet-500 to-purple-500 rounded-2xl mb-4 sm:mb-6">
                    <Target className="h-12 w-12 sm:h-16 sm:w-16 text-white" />
                  </div>
                  <h3 className="text-2xl sm:text-3xl md:text-4xl font-bold mb-2 sm:mb-4 bg-gradient-to-r from-white to-slate-300 bg-clip-text text-transparent">
                    +99% de satisfação
                  </h3>
                  <p className="text-sm sm:text-base text-slate-300">
                    Nossos clientes amam o Lucrei
                  </p>
                </div>
              </div>
            </motion.div>
          </motion.div>
        </div>
      </section>

      {/* Testimonials Section */}
      <section id="depoimentos" className="py-16 sm:py-24">
        <div className="container mx-auto px-4 sm:px-6 lg:px-8">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            className="text-center mb-12 sm:mb-16"
          >
            <Badge className="mb-4 bg-blue-500/20 border-blue-500/30 text-blue-300">
              Depoimentos
            </Badge>
            <h2 className="text-3xl sm:text-4xl md:text-5xl font-bold mb-4 sm:mb-6">
              O que nossos clientes{" "}
              <span className="bg-gradient-to-r from-blue-400 to-cyan-400 bg-clip-text text-transparent">
                dizem sobre nós
              </span>
            </h2>
            <p className="text-base sm:text-lg md:text-xl text-slate-400 max-w-2xl mx-auto">
              Histórias reais de quem transformou sua gestão financeira
            </p>
          </motion.div>

          <motion.div
            variants={stagger}
            initial="initial"
            whileInView="animate"
            viewport={{ once: true }}
            className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 sm:gap-8"
          >
            {testimonials.map((testimonial, index) => (
              <motion.div key={index} variants={fadeInUp} whileHover={{ y: -8, scale: 1.02 }}>
                <Card className="h-full bg-slate-900/50 border-white/10 backdrop-blur-sm hover:border-white/20 transition-all">
                  <CardContent className="p-6 sm:p-8">
                    <div className="flex items-center gap-1 mb-4 sm:mb-6">
                      {[...Array(testimonial.rating)].map((_, i) => (
                        <Star key={i} className="h-4 w-4 sm:h-5 sm:w-5 fill-yellow-400 text-yellow-400" />
                      ))}
                    </div>
                    <p className="text-sm sm:text-base text-slate-300 mb-6 sm:mb-8 leading-relaxed">
                      "{testimonial.content}"
                    </p>
                    <div className="flex items-center gap-3 sm:gap-4">
                      <div className={`h-10 w-10 sm:h-12 sm:w-12 rounded-full bg-gradient-to-br ${testimonial.gradient} flex items-center justify-center text-white font-bold text-sm sm:text-base shrink-0`}>
                        {testimonial.avatar}
                      </div>
                      <div className="min-w-0">
                        <div className="font-bold text-white text-sm sm:text-base truncate">{testimonial.name}</div>
                        <div className="text-xs sm:text-sm text-slate-400 truncate">{testimonial.role}</div>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              </motion.div>
            ))}
          </motion.div>
        </div>
      </section>

      {/* Pricing Section */}
      <section id="precos" className="py-16 sm:py-24 bg-gradient-to-b from-transparent via-slate-900/50 to-transparent">
        <div className="container mx-auto px-4 sm:px-6 lg:px-8">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            className="text-center mb-12 sm:mb-16"
          >
            <Badge className="mb-4 bg-purple-500/20 border-purple-500/30 text-purple-300">
              Planos e Preços
            </Badge>
            <h2 className="text-3xl sm:text-4xl md:text-5xl font-bold mb-4 sm:mb-6">
              Escolha o plano{" "}
              <span className="bg-gradient-to-r from-purple-400 to-pink-400 bg-clip-text text-transparent">
                ideal para você
              </span>
            </h2>
            <p className="text-base sm:text-lg md:text-xl text-slate-400 max-w-2xl mx-auto">
              Sem surpresas, sem taxas ocultas. Cancele quando quiser.
            </p>
          </motion.div>

          <motion.div
            variants={stagger}
            initial="initial"
            whileInView="animate"
            viewport={{ once: true }}
            className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 sm:gap-8 max-w-6xl mx-auto"
          >
            {plans.map((plan, index) => (
              <motion.div
                key={index}
                variants={fadeInUp}
                whileHover={{ y: -8, scale: 1.02 }}
                className="relative"
              >
                {plan.popular && (
                  <div className="absolute -top-4 left-0 right-0 flex justify-center">
                    <Badge className="bg-gradient-to-r from-violet-500 to-purple-500 text-white border-0 shadow-lg">
                      <Award className="h-3 w-3 mr-1" />
                      Mais Popular
                    </Badge>
                  </div>
                )}
                <Card className={`h-full ${plan.popular ? 'bg-gradient-to-b from-slate-800/80 to-slate-900/80 border-2 border-violet-500/50 shadow-xl shadow-violet-500/20' : 'bg-slate-900/50 border-white/10'} backdrop-blur-sm hover:border-white/20 transition-all`}>
                  <CardContent className="p-6 sm:p-8">
                    <div className="text-center mb-6 sm:mb-8">
                      <h3 className="text-xl sm:text-2xl font-bold mb-2 text-white">{plan.name}</h3>
                      <p className="text-xs sm:text-sm text-slate-400 mb-4">{plan.description}</p>
                      {plan.discount && (
                        <Badge className="mb-4 bg-green-500/20 border-green-500/30 text-green-300 text-xs">
                          {plan.discount}
                        </Badge>
                      )}
                      <div className="flex items-baseline justify-center gap-1">
                        <span className="text-base sm:text-lg text-slate-400">R$</span>
                        <span className={`text-4xl sm:text-5xl font-bold bg-gradient-to-r ${plan.gradient} bg-clip-text text-transparent`}>
                          {plan.price}
                        </span>
                        <span className="text-base sm:text-lg text-slate-400">{plan.period}</span>
                      </div>
                    </div>

                    <ul className="space-y-3 sm:space-y-4 mb-6 sm:mb-8">
                      {plan.features.map((feature, i) => (
                        <li key={i} className="flex items-start gap-2 sm:gap-3">
                          <CheckCircle2 className="h-4 w-4 sm:h-5 sm:w-5 text-green-400 shrink-0 mt-0.5" />
                          <span className="text-xs sm:text-sm text-slate-300">{feature}</span>
                        </li>
                      ))}
                    </ul>

                    <Link href="/login">
                      <Button
                        className={`w-full ${plan.popular ? `bg-gradient-to-r ${plan.gradient} hover:opacity-90` : 'bg-white/10 hover:bg-white/20'} text-white font-semibold text-sm sm:text-base h-11 sm:h-12`}
                      >
                        Começar Agora
                        <ArrowRight className="h-4 w-4 ml-2" />
                      </Button>
                    </Link>
                  </CardContent>
                </Card>
              </motion.div>
            ))}
          </motion.div>
        </div>
      </section>

      {/* FAQ Section */}
      <section className="py-16 sm:py-24">
        <div className="container mx-auto px-4 sm:px-6 lg:px-8 max-w-4xl">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            className="text-center mb-12 sm:mb-16"
          >
            <Badge className="mb-4 bg-cyan-500/20 border-cyan-500/30 text-cyan-300">
              Perguntas Frequentes
            </Badge>
            <h2 className="text-3xl sm:text-4xl md:text-5xl font-bold mb-4 sm:mb-6">
              Dúvidas?{" "}
              <span className="bg-gradient-to-r from-cyan-400 to-blue-400 bg-clip-text text-transparent">
                Nós respondemos
              </span>
            </h2>
            <p className="text-base sm:text-lg text-slate-400">
              Encontre respostas para as perguntas mais comuns
            </p>
          </motion.div>

          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
          >
            <Accordion type="single" collapsible className="space-y-4">
              {faqs.map((faq, index) => (
                <AccordionItem
                  key={index}
                  value={`item-${index}`}
                  className="bg-slate-900/50 border-white/10 rounded-lg px-4 sm:px-6 backdrop-blur-sm hover:border-white/20 transition-all"
                >
                  <AccordionTrigger className="text-left text-sm sm:text-base text-white hover:text-violet-300 py-4 sm:py-5">
                    {faq.question}
                  </AccordionTrigger>
                  <AccordionContent className="text-xs sm:text-sm text-slate-400 pb-4 sm:pb-5 leading-relaxed">
                    {faq.answer}
                  </AccordionContent>
                </AccordionItem>
              ))}
            </Accordion>
          </motion.div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-16 sm:py-24 relative overflow-hidden">
        <div className="absolute inset-0 bg-gradient-to-r from-violet-500/10 via-purple-500/10 to-pink-500/10" />
        <div className="absolute inset-0 bg-[linear-gradient(to_right,#80808012_1px,transparent_1px),linear-gradient(to_bottom,#80808012_1px,transparent_1px)] bg-[size:24px_24px]" />

        <div className="container mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
          <motion.div
            initial={{ opacity: 0, scale: 0.9 }}
            whileInView={{ opacity: 1, scale: 1 }}
            viewport={{ once: true }}
            className="max-w-4xl mx-auto text-center"
          >
            <div className="p-8 sm:p-12 md:p-16 bg-gradient-to-br from-violet-500/20 to-purple-500/20 border-2 border-white/10 rounded-3xl backdrop-blur-sm">
              <Sparkles className="h-12 w-12 sm:h-16 sm:w-16 text-violet-400 mx-auto mb-6 sm:mb-8" />
              <h2 className="text-3xl sm:text-4xl md:text-5xl font-bold mb-4 sm:mb-6">
                Pronto para transformar{" "}
                <span className="bg-gradient-to-r from-violet-400 to-purple-400 bg-clip-text text-transparent">
                  suas finanças
                </span>
                ?
              </h2>
              <p className="text-base sm:text-lg md:text-xl text-slate-300 mb-8 sm:mb-10 max-w-2xl mx-auto">
                Junte-se a milhares de empresas que já estão gerenciando suas finanças
                de forma inteligente com o Lucrei.
              </p>
              <Link href="/login">
                <Button size="lg" className="text-base sm:text-xl px-8 sm:px-12 h-14 sm:h-16 bg-gradient-to-r from-violet-500 via-purple-500 to-pink-500 hover:from-violet-600 hover:via-purple-600 hover:to-pink-600 shadow-2xl shadow-purple-500/50 group">
                  <Rocket className="h-6 w-6 mr-3 group-hover:rotate-12 transition-transform" />
                  Começar Gratuitamente Agora
                  <ArrowRight className="h-6 w-6 ml-3 group-hover:translate-x-1 transition-transform" />
                </Button>
              </Link>
              <p className="text-xs sm:text-sm text-slate-400 mt-6">
                Sem cartão de crédito • Cancele quando quiser
              </p>
            </div>
          </motion.div>
        </div>
      </section>

      {/* Footer */}
      <footer className="py-12 sm:py-16 border-t border-white/10">
        <div className="container mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-2 md:grid-cols-4 gap-8 sm:gap-12 mb-8 sm:mb-12">
            <div className="col-span-2 md:col-span-1">
              <div className="flex items-center gap-2 mb-4">
                <div className="p-2 bg-gradient-to-br from-violet-500 to-purple-500 rounded-xl">
                  <Zap className="h-5 w-5 sm:h-6 sm:w-6 text-white" />
                </div>
                <span className="text-xl sm:text-2xl font-bold bg-gradient-to-r from-violet-400 to-purple-400 bg-clip-text text-transparent">
                  Lucrei
                </span>
              </div>
              <p className="text-xs sm:text-sm text-slate-400 leading-relaxed">
                Sistema completo de gestão financeira para MEI, micro e pequenas empresas.
              </p>
            </div>

            <div>
              <h4 className="text-sm sm:text-base font-bold text-white mb-3 sm:mb-4">Produto</h4>
              <ul className="space-y-2">
                <li><a href="#recursos" className="text-xs sm:text-sm text-slate-400 hover:text-white transition-colors">Recursos</a></li>
                <li><a href="#precos" className="text-xs sm:text-sm text-slate-400 hover:text-white transition-colors">Preços</a></li>
                <li><a href="#" className="text-xs sm:text-sm text-slate-400 hover:text-white transition-colors">Atualizações</a></li>
              </ul>
            </div>

            <div>
              <h4 className="text-sm sm:text-base font-bold text-white mb-3 sm:mb-4">Empresa</h4>
              <ul className="space-y-2">
                <li><a href="#" className="text-xs sm:text-sm text-slate-400 hover:text-white transition-colors">Sobre nós</a></li>
                <li><a href="#depoimentos" className="text-xs sm:text-sm text-slate-400 hover:text-white transition-colors">Depoimentos</a></li>
                <li><a href="#" className="text-xs sm:text-sm text-slate-400 hover:text-white transition-colors">Contato</a></li>
              </ul>
            </div>

            <div>
              <h4 className="text-sm sm:text-base font-bold text-white mb-3 sm:mb-4">Suporte</h4>
              <ul className="space-y-2">
                <li><a href="#" className="text-xs sm:text-sm text-slate-400 hover:text-white transition-colors">Central de Ajuda</a></li>
                <li><a href="#" className="text-xs sm:text-sm text-slate-400 hover:text-white transition-colors">Documentação</a></li>
                <li><a href="#" className="text-xs sm:text-sm text-slate-400 hover:text-white transition-colors">Status</a></li>
              </ul>
            </div>
          </div>

          <div className="pt-8 border-t border-white/10 flex flex-col sm:flex-row items-center justify-between gap-4">
            <p className="text-xs sm:text-sm text-slate-400 text-center sm:text-left">
              © 2025 Lucrei. Todos os direitos reservados.
            </p>
            <div className="flex items-center gap-4 sm:gap-6">
              <a href="#" className="text-xs sm:text-sm text-slate-400 hover:text-white transition-colors">Privacidade</a>
              <a href="#" className="text-xs sm:text-sm text-slate-400 hover:text-white transition-colors">Termos</a>
              <a href="#" className="text-xs sm:text-sm text-slate-400 hover:text-white transition-colors">Cookies</a>
            </div>
          </div>
        </div>
      </footer>
    </div>
  );
}
