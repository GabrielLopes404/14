import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Switch } from "@/components/ui/switch";
import { Separator } from "@/components/ui/separator";
import { Shield, Bell, Database, Palette, Globe } from "lucide-react";

export default function AdminSettings() {
  return (
    <div className="p-6 space-y-6 animate-in fade-in duration-500">
      <div>
        <h1 className="text-3xl font-bold tracking-tight">Configurações do Sistema</h1>
        <p className="text-muted-foreground">
          Gerencie as configurações gerais do sistema
        </p>
      </div>

      <div className="grid gap-6">
        <Card className="hover-elevate transition-all duration-300">
          <CardHeader>
            <div className="flex items-center gap-2">
              <Shield className="h-5 w-5 text-primary" />
              <CardTitle>Segurança</CardTitle>
            </div>
            <CardDescription>
              Configure as opções de segurança e autenticação
            </CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="flex items-center justify-between">
              <div className="space-y-0.5">
                <Label>Autenticação de Dois Fatores</Label>
                <p className="text-sm text-muted-foreground">
                  Exigir 2FA para todos os administradores
                </p>
              </div>
              <Switch />
            </div>
            <Separator />
            <div className="flex items-center justify-between">
              <div className="space-y-0.5">
                <Label>Expiração de Sessão</Label>
                <p className="text-sm text-muted-foreground">
                  Tempo limite de inatividade (em minutos)
                </p>
              </div>
              <Input type="number" defaultValue="30" className="w-24" />
            </div>
            <Separator />
            <div className="flex items-center justify-between">
              <div className="space-y-0.5">
                <Label>Política de Senhas Fortes</Label>
                <p className="text-sm text-muted-foreground">
                  Exigir senhas complexas (min. 8 caracteres)
                </p>
              </div>
              <Switch defaultChecked />
            </div>
          </CardContent>
        </Card>

        <Card className="hover-elevate transition-all duration-300">
          <CardHeader>
            <div className="flex items-center gap-2">
              <Bell className="h-5 w-5 text-primary" />
              <CardTitle>Notificações</CardTitle>
            </div>
            <CardDescription>
              Configure as notificações do sistema
            </CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="flex items-center justify-between">
              <div className="space-y-0.5">
                <Label>Notificações por Email</Label>
                <p className="text-sm text-muted-foreground">
                  Enviar alertas importantes por email
                </p>
              </div>
              <Switch defaultChecked />
            </div>
            <Separator />
            <div className="flex items-center justify-between">
              <div className="space-y-0.5">
                <Label>Alertas de Segurança</Label>
                <p className="text-sm text-muted-foreground">
                  Notificar sobre tentativas de acesso suspeitas
                </p>
              </div>
              <Switch defaultChecked />
            </div>
            <Separator />
            <div className="flex items-center justify-between">
              <div className="space-y-0.5">
                <Label>Relatórios Diários</Label>
                <p className="text-sm text-muted-foreground">
                  Receber resumo diário de atividades
                </p>
              </div>
              <Switch />
            </div>
          </CardContent>
        </Card>

        <Card className="hover-elevate transition-all duration-300">
          <CardHeader>
            <div className="flex items-center gap-2">
              <Database className="h-5 w-5 text-primary" />
              <CardTitle>Banco de Dados</CardTitle>
            </div>
            <CardDescription>
              Opções de backup e manutenção
            </CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="flex items-center justify-between">
              <div className="space-y-0.5">
                <Label>Backup Automático</Label>
                <p className="text-sm text-muted-foreground">
                  Realizar backup diário automaticamente
                </p>
              </div>
              <Switch defaultChecked />
            </div>
            <Separator />
            <div className="space-y-2">
              <Label>Último Backup</Label>
              <p className="text-sm text-muted-foreground">
                02/11/2024 às 22:00
              </p>
              <Button variant="outline" size="sm">
                Fazer Backup Agora
              </Button>
            </div>
          </CardContent>
        </Card>

        <Card className="hover-elevate transition-all duration-300">
          <CardHeader>
            <div className="flex items-center gap-2">
              <Palette className="h-5 w-5 text-primary" />
              <CardTitle>Aparência</CardTitle>
            </div>
            <CardDescription>
              Personalize a aparência do sistema
            </CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="space-y-2">
              <Label>Cor Primária</Label>
              <div className="flex gap-2">
                <div className="w-10 h-10 rounded-full bg-primary border-2 border-primary cursor-pointer" />
                <div className="w-10 h-10 rounded-full bg-blue-500 border-2 border-transparent hover:border-primary cursor-pointer" />
                <div className="w-10 h-10 rounded-full bg-green-500 border-2 border-transparent hover:border-primary cursor-pointer" />
                <div className="w-10 h-10 rounded-full bg-purple-500 border-2 border-transparent hover:border-primary cursor-pointer" />
              </div>
            </div>
            <Separator />
            <div className="flex items-center justify-between">
              <div className="space-y-0.5">
                <Label>Modo Escuro Padrão</Label>
                <p className="text-sm text-muted-foreground">
                  Usar tema escuro como padrão
                </p>
              </div>
              <Switch />
            </div>
          </CardContent>
        </Card>

        <Card className="hover-elevate transition-all duration-300">
          <CardHeader>
            <div className="flex items-center gap-2">
              <Globe className="h-5 w-5 text-primary" />
              <CardTitle>Localização e Idioma</CardTitle>
            </div>
            <CardDescription>
              Configure o idioma e fuso horário
            </CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="space-y-2">
              <Label>Idioma do Sistema</Label>
              <Input defaultValue="Português (Brasil)" disabled />
            </div>
            <div className="space-y-2">
              <Label>Fuso Horário</Label>
              <Input defaultValue="America/Sao_Paulo (GMT-3)" disabled />
            </div>
          </CardContent>
        </Card>

        <div className="flex justify-end">
          <Button size="lg">
            Salvar Todas as Configurações
          </Button>
        </div>
      </div>
    </div>
  );
}
