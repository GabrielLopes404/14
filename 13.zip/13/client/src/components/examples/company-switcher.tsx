import { CompanySwitcher } from '../company-switcher';

export default function CompanySwitcherExample() {
  return (
    <div className="p-6">
      <CompanySwitcher />
    </div>
  );
}
